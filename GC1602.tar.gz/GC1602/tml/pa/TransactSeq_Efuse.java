package pa;

import xoc.dsa.ISetupProtocolInterface;

public class TransactSeq_Efuse  extends TransactSeq {

    public TransactSeq_Efuse(ISetupProtocolInterface paInterface, String name) {
        super(paInterface, name);
        // TODO Auto-generated constructor stub
    }

}
