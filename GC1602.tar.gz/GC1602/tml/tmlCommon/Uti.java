package tmlCommon;

public class Uti {

    public static String l2hexStr(long in) {
        return null;
    }

}
