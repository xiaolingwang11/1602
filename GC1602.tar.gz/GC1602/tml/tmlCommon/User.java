package tmlCommon;

public class User {

    public static final boolean isDebug = true;


}
